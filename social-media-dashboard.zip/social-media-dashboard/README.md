# Social Media Dashboard

A full-stack social media analytics dashboard built with:

- React.js + Vite
- Node.js + Express
- PostgreSQL
- JWT authentication
- Recharts
- REST APIs
- Twitter/X and Instagram service placeholders

## Project structure

```text
social-media-dashboard/
├── frontend/
├── backend/
├── database/
├── .gitignore
└── README.md
```

## Requirements

- Node.js 18+
- PostgreSQL 14+
- npm

## 1. Create the database

```sql
CREATE DATABASE social_dashboard;
```

Then run:

```bash
psql -U postgres -d social_dashboard -f database/schema.sql
```

## 2. Configure backend

Copy:

```text
backend/.env.example
```

to:

```text
backend/.env
```

Set your PostgreSQL credentials and JWT secret.

## 3. Start backend

```bash
cd backend
npm install
npm run dev
```

Backend runs on:

```text
http://localhost:5000
```

## 4. Start frontend

In another terminal:

```bash
cd frontend
npm install
npm run dev
```

Frontend runs on the Vite URL, normally:

```text
http://localhost:5173
```

## Social API setup

The project includes service modules for Twitter/X and Instagram. Add valid API credentials to `.env` when you are ready to connect real platform APIs.

The dashboard works with seeded/demo analytics without requiring social API credentials.
