CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    avatar_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS social_accounts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    platform VARCHAR(30) NOT NULL,
    platform_user_id VARCHAR(255),
    username VARCHAR(100),
    access_token TEXT,
    refresh_token TEXT,
    followers_count INTEGER DEFAULT 0,
    following_count INTEGER DEFAULT 0,
    profile_image_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, platform)
);

CREATE TABLE IF NOT EXISTS posts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    social_account_id INTEGER REFERENCES social_accounts(id) ON DELETE SET NULL,
    platform VARCHAR(30) NOT NULL,
    content TEXT NOT NULL,
    media_url TEXT,
    status VARCHAR(30) DEFAULT 'draft',
    scheduled_at TIMESTAMP,
    published_at TIMESTAMP,
    likes_count INTEGER DEFAULT 0,
    comments_count INTEGER DEFAULT 0,
    shares_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS analytics (
    id SERIAL PRIMARY KEY,
    social_account_id INTEGER NOT NULL REFERENCES social_accounts(id) ON DELETE CASCADE,
    metric_date DATE NOT NULL,
    followers INTEGER DEFAULT 0,
    impressions INTEGER DEFAULT 0,
    reach INTEGER DEFAULT 0,
    likes INTEGER DEFAULT 0,
    comments INTEGER DEFAULT 0,
    shares INTEGER DEFAULT 0,
    engagement_rate NUMERIC(6,2) DEFAULT 0,
    UNIQUE(social_account_id, metric_date)
);

CREATE INDEX IF NOT EXISTS idx_social_accounts_user_id
ON social_accounts(user_id);

CREATE INDEX IF NOT EXISTS idx_posts_user_id
ON posts(user_id);

CREATE INDEX IF NOT EXISTS idx_posts_scheduled_at
ON posts(scheduled_at);

CREATE INDEX IF NOT EXISTS idx_analytics_account_date
ON analytics(social_account_id, metric_date);

-- Demo user:
-- Password is "password123" when using the development seed endpoint.
-- The application can also create users through /api/auth/register.

INSERT INTO users (name, email, password_hash)
VALUES (
    'Demo User',
    'demo@example.com',
    '$2b$10$7EqJtq98hPqEX7fNZaFWoOQz9x7pZx5p7w9cVxQ2X2m7Hq4YhM5fK'
)
ON CONFLICT (email) DO NOTHING;
