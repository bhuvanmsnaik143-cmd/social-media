require("dotenv").config();
const pool = require("./db/database");

async function seed() {
  try {
    const user = await pool.query(
      `SELECT id FROM users WHERE email = 'demo@example.com'`
    );

    if (!user.rows.length) {
      console.log("Demo user does not exist. Run schema.sql first.");
      return;
    }

    const userId = user.rows[0].id;

    await pool.query(
      `INSERT INTO social_accounts
       (user_id, platform, username, followers_count, following_count)
       VALUES
       ($1, 'instagram', '@creator', 10200, 640),
       ($1, 'twitter', '@creator', 15230, 810)
       ON CONFLICT (user_id, platform) DO UPDATE
       SET followers_count = EXCLUDED.followers_count`,
      [userId]
    );

    const accounts = await pool.query(
      "SELECT id FROM social_accounts WHERE user_id = $1",
      [userId]
    );

    for (const account of accounts.rows) {
      for (let i = 29; i >= 0; i--) {
        await pool.query(
          `INSERT INTO analytics
           (social_account_id, metric_date, followers, impressions, reach, likes, comments, shares, engagement_rate)
           VALUES
           ($1, CURRENT_DATE - ($2 || ' days')::interval,
            $3, $4, $5, $6, $7, $8, $9)
           ON CONFLICT (social_account_id, metric_date)
           DO UPDATE SET
             followers = EXCLUDED.followers,
             impressions = EXCLUDED.impressions,
             reach = EXCLUDED.reach,
             likes = EXCLUDED.likes,
             comments = EXCLUDED.comments,
             shares = EXCLUDED.shares,
             engagement_rate = EXCLUDED.engagement_rate`,
          [
            account.id,
            i,
            9000 + (29 - i) * 220,
            15000 + (29 - i) * 700,
            12000 + (29 - i) * 520,
            200 + (29 - i) * 18,
            40 + (29 - i) * 4,
            20 + (29 - i) * 3,
            6.5 + (29 - i) * 0.08
          ]
        );
      }
    }

    console.log("Demo data seeded successfully.");
  } finally {
    await pool.end();
  }
}

seed().catch((error) => {
  console.error(error);
  process.exit(1);
});
