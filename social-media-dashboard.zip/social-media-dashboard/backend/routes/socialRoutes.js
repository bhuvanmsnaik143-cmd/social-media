const router = require("express").Router();
const controller = require("../controllers/socialController");
const auth = require("../middleware/authMiddleware");

router.get("/", auth, controller.listAccounts);
router.post("/connect", auth, controller.connect);
router.delete("/:id", auth, controller.disconnect);

module.exports = router;
