const router = require("express").Router();
const controller = require("../controllers/analyticsController");
const auth = require("../middleware/authMiddleware");

router.get("/summary", auth, controller.summary);
router.get("/timeline", auth, controller.timeline);
router.get("/platforms", auth, controller.platforms);

module.exports = router;
