const router = require("express").Router();
const controller = require("../controllers/postController");
const auth = require("../middleware/authMiddleware");

router.get("/", auth, controller.list);
router.post("/", auth, controller.create);
router.put("/:id", auth, controller.update);
router.delete("/:id", auth, controller.remove);

module.exports = router;
