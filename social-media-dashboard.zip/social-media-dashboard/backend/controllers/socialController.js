const pool = require("../db/database");

exports.listAccounts = async (req, res) => {
  const result = await pool.query(
    `SELECT id, platform, platform_user_id, username,
            followers_count, following_count, profile_image_url,
            created_at, updated_at
     FROM social_accounts
     WHERE user_id = $1
     ORDER BY platform`,
    [req.user.id]
  );

  res.json(result.rows);
};

exports.connect = async (req, res) => {
  try {
    const {
      platform,
      platformUserId,
      username,
      accessToken,
      refreshToken,
      followersCount = 0,
      followingCount = 0,
      profileImageUrl
    } = req.body;

    if (!["twitter", "instagram"].includes(platform)) {
      return res.status(400).json({ message: "Supported platforms: twitter, instagram" });
    }

    const result = await pool.query(
      `INSERT INTO social_accounts
       (user_id, platform, platform_user_id, username, access_token,
        refresh_token, followers_count, following_count, profile_image_url)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       ON CONFLICT (user_id, platform)
       DO UPDATE SET
         platform_user_id = EXCLUDED.platform_user_id,
         username = EXCLUDED.username,
         access_token = EXCLUDED.access_token,
         refresh_token = EXCLUDED.refresh_token,
         followers_count = EXCLUDED.followers_count,
         following_count = EXCLUDED.following_count,
         profile_image_url = EXCLUDED.profile_image_url,
         updated_at = CURRENT_TIMESTAMP
       RETURNING id, platform, username, followers_count, following_count`,
      [
        req.user.id,
        platform,
        platformUserId || null,
        username || null,
        accessToken || null,
        refreshToken || null,
        followersCount,
        followingCount,
        profileImageUrl || null
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not connect social account" });
  }
};

exports.disconnect = async (req, res) => {
  await pool.query(
    "DELETE FROM social_accounts WHERE id = $1 AND user_id = $2",
    [req.params.id, req.user.id]
  );

  res.json({ message: "Social account disconnected" });
};
