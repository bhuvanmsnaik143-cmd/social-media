const pool = require("../db/database");

exports.summary = async (req, res) => {
  try {
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT
        COALESCE(SUM(sa.followers_count), 0)::int AS followers,
        COALESCE(SUM(a.impressions), 0)::int AS impressions,
        COALESCE(SUM(a.reach), 0)::int AS reach,
        COALESCE(SUM(a.likes), 0)::int AS likes,
        COALESCE(SUM(a.comments), 0)::int AS comments,
        COALESCE(SUM(a.shares), 0)::int AS shares,
        COALESCE(AVG(a.engagement_rate), 0)::float AS engagement_rate
       FROM social_accounts sa
       LEFT JOIN analytics a
         ON a.social_account_id = sa.id
         AND a.metric_date >= CURRENT_DATE - INTERVAL '30 days'
       WHERE sa.user_id = $1`,
      [userId]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not load summary" });
  }
};

exports.timeline = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT
        a.metric_date,
        SUM(a.followers)::int AS followers,
        SUM(a.impressions)::int AS impressions,
        SUM(a.reach)::int AS reach,
        SUM(a.likes)::int AS likes,
        SUM(a.comments)::int AS comments,
        SUM(a.shares)::int AS shares
       FROM analytics a
       JOIN social_accounts sa ON sa.id = a.social_account_id
       WHERE sa.user_id = $1
       GROUP BY a.metric_date
       ORDER BY a.metric_date ASC`,
      [req.user.id]
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not load analytics timeline" });
  }
};

exports.platforms = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT
        sa.platform,
        sa.username,
        sa.followers_count,
        COALESCE(SUM(a.likes), 0)::int AS likes,
        COALESCE(SUM(a.comments), 0)::int AS comments,
        COALESCE(SUM(a.shares), 0)::int AS shares,
        COALESCE(AVG(a.engagement_rate), 0)::float AS engagement_rate
       FROM social_accounts sa
       LEFT JOIN analytics a ON a.social_account_id = sa.id
       WHERE sa.user_id = $1
       GROUP BY sa.id
       ORDER BY sa.platform`,
      [req.user.id]
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not load platform analytics" });
  }
};
