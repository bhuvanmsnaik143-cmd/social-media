const pool = require("../db/database");

exports.list = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT p.*, sa.username
       FROM posts p
       LEFT JOIN social_accounts sa ON sa.id = p.social_account_id
       WHERE p.user_id = $1
       ORDER BY COALESCE(p.scheduled_at, p.created_at) DESC`,
      [req.user.id]
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not load posts" });
  }
};

exports.create = async (req, res) => {
  try {
    const {
      socialAccountId,
      platform,
      content,
      mediaUrl,
      status = "draft",
      scheduledAt
    } = req.body;

    if (!platform || !content) {
      return res.status(400).json({ message: "Platform and content are required" });
    }

    const result = await pool.query(
      `INSERT INTO posts
       (user_id, social_account_id, platform, content, media_url, status, scheduled_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        req.user.id,
        socialAccountId || null,
        platform,
        content,
        mediaUrl || null,
        status,
        scheduledAt || null
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not create post" });
  }
};

exports.update = async (req, res) => {
  try {
    const { id } = req.params;
    const { content, status, scheduledAt } = req.body;

    const result = await pool.query(
      `UPDATE posts
       SET content = COALESCE($1, content),
           status = COALESCE($2, status),
           scheduled_at = COALESCE($3, scheduled_at),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $4 AND user_id = $5
       RETURNING *`,
      [content, status, scheduledAt, id, req.user.id]
    );

    if (!result.rows.length) {
      return res.status(404).json({ message: "Post not found" });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not update post" });
  }
};

exports.remove = async (req, res) => {
  try {
    const result = await pool.query(
      "DELETE FROM posts WHERE id = $1 AND user_id = $2 RETURNING id",
      [req.params.id, req.user.id]
    );

    if (!result.rows.length) {
      return res.status(404).json({ message: "Post not found" });
    }

    res.json({ message: "Post deleted" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not delete post" });
  }
};
