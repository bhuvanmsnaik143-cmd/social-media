/**
 * Instagram integration placeholder.
 *
 * Instagram publishing/insights generally use Meta's official APIs
 * and require an appropriate Instagram professional account and
 * Meta application configuration.
 */

async function getProfile(accessToken) {
  if (!accessToken) {
    throw new Error("Instagram access token is required");
  }

  return {
    platform: "instagram",
    connected: true,
    message: "Connect this service to the official Meta/Instagram API."
  };
}

module.exports = { getProfile };
