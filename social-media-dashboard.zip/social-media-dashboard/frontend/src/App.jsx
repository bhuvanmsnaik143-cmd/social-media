import { useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import api from "./services/api";

import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Analytics from "./pages/Analytics";
import Posts from "./pages/Posts";
import Schedule from "./pages/Schedule";
import Profile from "./pages/Profile";

function ProtectedRoute({ user, children }) {
  return user ? children : <Navigate to="/login" replace />;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("social_dashboard_token");

    if (!token) {
      setLoading(false);
      return;
    }

    api.get("/auth/me")
      .then((response) => setUser(response.data))
      .catch(() => {
        localStorage.removeItem("social_dashboard_token");
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="loading-screen">Loading SocialPulse...</div>;
  }

  return (
    <Routes>
      <Route
        path="/login"
        element={
          user
            ? <Navigate to="/" replace />
            : <Login onLogin={setUser} />
        }
      />

      <Route
        path="/register"
        element={
          user
            ? <Navigate to="/" replace />
            : <Register onRegister={setUser} />
        }
      />

      <Route
        path="/*"
        element={
          <ProtectedRoute user={user}>
            <Dashboard user={user} onLogout={() => setUser(null)} />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}

export function AppPages({ user, onLogout }) {
  return null;
}
