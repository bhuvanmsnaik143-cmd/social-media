import { Routes, Route } from "react-router-dom";
import Layout from "../components/Layout";
import DashboardHome from "./DashboardHome";
import Analytics from "./Analytics";
import Posts from "./Posts";
import Schedule from "./Schedule";
import Profile from "./Profile";

export default function Dashboard({ user, onLogout }) {
  return (
    <Layout user={user} onLogout={onLogout}>
      <Routes>
        <Route index element={<DashboardHome />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="posts" element={<Posts />} />
        <Route path="schedule" element={<Schedule />} />
        <Route path="profile" element={<Profile user={user} />} />
      </Routes>
    </Layout>
  );
}
