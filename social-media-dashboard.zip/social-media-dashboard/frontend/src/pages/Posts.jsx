import { useEffect, useState } from "react";
import { Plus, Trash2, Send } from "lucide-react";
import api from "../services/api";
import PlatformBadge from "../components/PlatformBadge";

export default function Posts() {
  const [posts, setPosts] = useState([]);
  const [form, setForm] = useState({
    platform: "instagram",
    content: "",
    status: "draft"
  });
  const [message, setMessage] = useState("");

  async function load() {
    try {
      const response = await api.get("/posts");
      setPosts(response.data);
    } catch {
      setPosts([]);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function createPost(event) {
    event.preventDefault();

    if (!form.content.trim()) return;

    try {
      await api.post("/posts", form);
      setForm({ platform: "instagram", content: "", status: "draft" });
      setMessage("Post saved successfully.");
      load();
    } catch (error) {
      setMessage(error.response?.data?.message || "Could not save post.");
    }
  }

  async function deletePost(id) {
    await api.delete(`/posts/${id}`);
    load();
  }

  return (
    <>
      <section className="page-heading">
        <div>
          <span className="eyebrow">CONTENT</span>
          <h2>Create and manage posts</h2>
          <p>Prepare content for your connected social channels.</p>
        </div>
      </section>

      <div className="content-grid posts-grid">
        <section className="panel">
          <div className="panel-header">
            <div>
              <h3>New post</h3>
              <p>Create a draft or prepare content for scheduling.</p>
            </div>
          </div>

          <form className="post-form" onSubmit={createPost}>
            <label>
              Platform
              <select
                value={form.platform}
                onChange={(e) => setForm({ ...form, platform: e.target.value })}
              >
                <option value="instagram">Instagram</option>
                <option value="twitter">X / Twitter</option>
              </select>
            </label>

            <label>
              Content
              <textarea
                rows="8"
                placeholder="Write your post..."
                value={form.content}
                onChange={(e) => setForm({ ...form, content: e.target.value })}
              />
            </label>

            <button className="primary-button" type="submit">
              <Plus size={17} /> Save post
            </button>

            {message && <div className="form-message">{message}</div>}
          </form>
        </section>

        <section className="panel">
          <div className="panel-header">
            <div>
              <h3>Recent posts</h3>
              <p>Your latest content</p>
            </div>
          </div>

          <div className="post-list">
            {posts.length ? posts.map((post) => (
              <article className="post-card" key={post.id}>
                <div className="post-card-top">
                  <PlatformBadge platform={post.platform} />
                  <span className={`status ${post.status}`}>{post.status}</span>
                </div>
                <p>{post.content}</p>
                <div className="post-card-footer">
                  <small>{new Date(post.created_at).toLocaleString()}</small>
                  <button className="icon-button danger" onClick={() => deletePost(post.id)}>
                    <Trash2 size={16} />
                  </button>
                </div>
              </article>
            )) : (
              <div className="empty-state">
                <Send size={26} />
                <strong>No posts yet</strong>
                <span>Create your first post using the form.</span>
              </div>
            )}
          </div>
        </section>
      </div>
    </>
  );
}
