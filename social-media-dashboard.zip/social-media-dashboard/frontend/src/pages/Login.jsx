import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { BarChart3, Lock, Mail } from "lucide-react";
import api from "../services/api";

export default function Login({ onLogin }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  async function submit(event) {
    event.preventDefault();
    setError("");

    try {
      const response = await api.post("/auth/login", form);
      localStorage.setItem("social_dashboard_token", response.data.token);
      onLogin(response.data.user);
      navigate("/");
    } catch (err) {
      setError(err.response?.data?.message || "Login failed");
    }
  }

  return (
    <AuthLayout title="Welcome back" subtitle="Sign in to your social media command center.">
      <form className="auth-form" onSubmit={submit}>
        <label>
          <span>Email</span>
          <div className="input-icon">
            <Mail size={17} />
            <input type="email" required placeholder="you@example.com" value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
        </label>

        <label>
          <span>Password</span>
          <div className="input-icon">
            <Lock size={17} />
            <input type="password" required placeholder="••••••••" value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </div>
        </label>

        {error && <div className="error-message">{error}</div>}

        <button className="primary-button full" type="submit">Sign in</button>

        <p className="auth-switch">
          Don't have an account? <Link to="/register">Create one</Link>
        </p>
      </form>
    </AuthLayout>
  );
}

function AuthLayout({ title, subtitle, children }) {
  return (
    <div className="auth-page">
      <div className="auth-decoration">
        <div className="orb orb-one" />
        <div className="orb orb-two" />
      </div>

      <div className="auth-card">
        <div className="auth-brand">
          <div className="brand-mark"><BarChart3 size={22} /></div>
          <strong>SocialPulse</strong>
        </div>
        <h1>{title}</h1>
        <p>{subtitle}</p>
        {children}
      </div>
    </div>
  );
}
