import { useEffect, useState } from "react";
import { Instagram, Twitter, User, Unplug } from "lucide-react";
import api from "../services/api";

export default function Profile({ user }) {
  const [accounts, setAccounts] = useState([]);
  const [form, setForm] = useState({
    platform: "instagram",
    username: "",
    followersCount: 0
  });
  const [message, setMessage] = useState("");

  async function load() {
    try {
      const response = await api.get("/social");
      setAccounts(response.data);
    } catch {
      setAccounts([]);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function connect(event) {
    event.preventDefault();

    await api.post("/social/connect", form);
    setMessage(`${form.platform} account connected.`);
    setForm({ platform: "instagram", username: "", followersCount: 0 });
    load();
  }

  async function disconnect(id) {
    await api.delete(`/social/${id}`);
    load();
  }

  return (
    <>
      <section className="page-heading">
        <div>
          <span className="eyebrow">ACCOUNT</span>
          <h2>Your profile</h2>
          <p>Manage your profile and connected social accounts.</p>
        </div>
      </section>

      <div className="content-grid">
        <section className="panel profile-card">
          <div className="large-avatar"><User size={34} /></div>
          <h3>{user?.name}</h3>
          <p>{user?.email}</p>
          <span className="account-status">Account active</span>
        </section>

        <section className="panel">
          <div className="panel-header">
            <div>
              <h3>Connect social account</h3>
              <p>Demo connection form. Add OAuth for production.</p>
            </div>
          </div>

          <form className="post-form" onSubmit={connect}>
            <label>
              Platform
              <select value={form.platform} onChange={(e) => setForm({ ...form, platform: e.target.value })}>
                <option value="instagram">Instagram</option>
                <option value="twitter">X / Twitter</option>
              </select>
            </label>

            <label>
              Username
              <input
                value={form.username}
                placeholder="@yourname"
                onChange={(e) => setForm({ ...form, username: e.target.value })}
              />
            </label>

            <label>
              Followers
              <input
                type="number"
                min="0"
                value={form.followersCount}
                onChange={(e) => setForm({ ...form, followersCount: Number(e.target.value) })}
              />
            </label>

            <button className="primary-button">Connect account</button>
            {message && <div className="form-message">{message}</div>}
          </form>
        </section>

        <section className="panel">
          <div className="panel-header">
            <div>
              <h3>Connected accounts</h3>
              <p>Channels available for analytics.</p>
            </div>
          </div>

          <div className="platform-list">
            {accounts.length ? accounts.map((account) => (
              <div className="platform-row" key={account.id}>
                <div className="platform-logo">
                  {account.platform === "instagram" ? <Instagram size={20} /> : <Twitter size={20} />}
                </div>
                <div className="platform-info">
                  <strong>{account.username || "Connected account"}</strong>
                  <small>{account.platform}</small>
                </div>
                <strong>{Number(account.followers_count).toLocaleString()}</strong>
                <button className="icon-button danger" onClick={() => disconnect(account.id)}>
                  <Unplug size={16} />
                </button>
              </div>
            )) : (
              <div className="empty-state">
                <strong>No accounts connected</strong>
                <span>Use the form above to add a demo account.</span>
              </div>
            )}
          </div>
        </section>
      </div>
    </>
  );
}
