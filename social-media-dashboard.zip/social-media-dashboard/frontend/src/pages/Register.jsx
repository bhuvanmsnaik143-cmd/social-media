import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { User, Mail, Lock } from "lucide-react";
import api from "../services/api";

export default function Register({ onRegister }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");

  async function submit(event) {
    event.preventDefault();
    setError("");

    try {
      const response = await api.post("/auth/register", form);
      localStorage.setItem("social_dashboard_token", response.data.token);
      onRegister(response.data.user);
      navigate("/");
    } catch (err) {
      setError(err.response?.data?.message || "Registration failed");
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-brand">
          <div className="brand-mark">S</div>
          <strong>SocialPulse</strong>
        </div>

        <h1>Create account</h1>
        <p>Start managing your social media analytics.</p>

        <form className="auth-form" onSubmit={submit}>
          <label>
            <span>Name</span>
            <div className="input-icon">
              <User size={17} />
              <input required placeholder="Your name" value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
          </label>

          <label>
            <span>Email</span>
            <div className="input-icon">
              <Mail size={17} />
              <input type="email" required placeholder="you@example.com" value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
          </label>

          <label>
            <span>Password</span>
            <div className="input-icon">
              <Lock size={17} />
              <input type="password" required minLength="6" placeholder="Minimum 6 characters"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })} />
            </div>
          </label>

          {error && <div className="error-message">{error}</div>}

          <button className="primary-button full" type="submit">Create account</button>

          <p className="auth-switch">
            Already have an account? <Link to="/login">Sign in</Link>
          </p>
        </form>
      </div>
    </div>
  );
}
