import { useEffect, useState } from "react";
import { CalendarClock, Clock, Trash2 } from "lucide-react";
import api from "../services/api";

export default function Schedule() {
  const [posts, setPosts] = useState([]);
  const [form, setForm] = useState({
    platform: "instagram",
    content: "",
    scheduledAt: ""
  });

  async function load() {
    try {
      const response = await api.get("/posts");
      setPosts(response.data.filter((post) => post.status === "scheduled"));
    } catch {
      setPosts([]);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function schedulePost(event) {
    event.preventDefault();

    if (!form.content || !form.scheduledAt) return;

    await api.post("/posts", {
      platform: form.platform,
      content: form.content,
      status: "scheduled",
      scheduledAt: new Date(form.scheduledAt).toISOString()
    });

    setForm({
      platform: "instagram",
      content: "",
      scheduledAt: ""
    });

    load();
  }

  async function remove(id) {
    await api.delete(`/posts/${id}`);
    load();
  }

  return (
    <>
      <section className="page-heading">
        <div>
          <span className="eyebrow">PUBLISHING</span>
          <h2>Schedule content</h2>
          <p>Plan your upcoming social media posts.</p>
        </div>
      </section>

      <div className="content-grid">
        <section className="panel">
          <div className="panel-header">
            <div>
              <h3>Schedule a post</h3>
              <p>Select a channel, date and time.</p>
            </div>
          </div>

          <form className="post-form" onSubmit={schedulePost}>
            <label>
              Platform
              <select value={form.platform} onChange={(e) => setForm({ ...form, platform: e.target.value })}>
                <option value="instagram">Instagram</option>
                <option value="twitter">X / Twitter</option>
              </select>
            </label>

            <label>
              Date and time
              <input
                type="datetime-local"
                value={form.scheduledAt}
                onChange={(e) => setForm({ ...form, scheduledAt: e.target.value })}
              />
            </label>

            <label>
              Content
              <textarea
                rows="6"
                placeholder="What would you like to publish?"
                value={form.content}
                onChange={(e) => setForm({ ...form, content: e.target.value })}
              />
            </label>

            <button className="primary-button" type="submit">
              <CalendarClock size={17} /> Schedule post
            </button>
          </form>
        </section>

        <section className="panel">
          <div className="panel-header">
            <div>
              <h3>Upcoming posts</h3>
              <p>Scheduled content</p>
            </div>
          </div>

          <div className="schedule-list">
            {posts.length ? posts.map((post) => (
              <article className="schedule-item" key={post.id}>
                <div className="schedule-icon"><Clock size={19} /></div>
                <div className="schedule-copy">
                  <strong>{post.platform === "instagram" ? "Instagram" : "X / Twitter"}</strong>
                  <p>{post.content}</p>
                  <small>{new Date(post.scheduled_at).toLocaleString()}</small>
                </div>
                <button className="icon-button danger" onClick={() => remove(post.id)}>
                  <Trash2 size={16} />
                </button>
              </article>
            )) : (
              <div className="empty-state">
                <CalendarClock size={26} />
                <strong>No scheduled posts</strong>
                <span>Your upcoming content will appear here.</span>
              </div>
            )}
          </div>
        </section>
      </div>
    </>
  );
}
