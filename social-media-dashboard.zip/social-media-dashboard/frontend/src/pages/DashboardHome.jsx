import { useEffect, useState } from "react";
import {
  Users,
  Heart,
  Eye,
  FileText,
  ArrowUpRight,
  Instagram,
  Twitter
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from "recharts";
import api from "../services/api";
import MetricCard from "../components/MetricCard";

const demoTimeline = [
  { metric_date: "Sep 01", followers: 18400, reach: 42000 },
  { metric_date: "Sep 05", followers: 19100, reach: 45600 },
  { metric_date: "Sep 10", followers: 19800, reach: 48300 },
  { metric_date: "Sep 15", followers: 20700, reach: 52100 },
  { metric_date: "Sep 20", followers: 21800, reach: 55700 },
  { metric_date: "Sep 25", followers: 23200, reach: 61200 },
  { metric_date: "Sep 30", followers: 25430, reach: 68400 }
];

export default function DashboardHome() {
  const [summary, setSummary] = useState({});
  const [timeline, setTimeline] = useState(demoTimeline);
  const [platforms, setPlatforms] = useState([]);

  useEffect(() => {
    Promise.all([
      api.get("/analytics/summary"),
      api.get("/analytics/timeline"),
      api.get("/analytics/platforms")
    ])
      .then(([summaryRes, timelineRes, platformRes]) => {
        setSummary(summaryRes.data || {});
        if (timelineRes.data?.length) setTimeline(timelineRes.data);
        setPlatforms(platformRes.data || []);
      })
      .catch(() => {});
  }, []);

  const fmt = (value) => Number(value || 0).toLocaleString();
  const engagement = Number(summary.engagement_rate || 8.42).toFixed(2);

  return (
    <>
      <section className="page-heading">
        <div>
          <span className="eyebrow">OVERVIEW</span>
          <h2>Performance at a glance</h2>
          <p>Monitor your connected social channels and recent activity.</p>
        </div>
        <a className="primary-button" href="/posts">
          Create post <ArrowUpRight size={17} />
        </a>
      </section>

      <div className="metrics-grid">
        <MetricCard title="Followers" value={fmt(summary.followers || 25430)} detail="across channels" trend="+12.8%" icon={Users} />
        <MetricCard title="Engagement rate" value={`${engagement}%`} detail="last 30 days" trend="+1.4%" icon={Heart} />
        <MetricCard title="Reach" value={fmt(summary.reach || 68400)} detail="last 30 days" trend="+18.2%" icon={Eye} />
        <MetricCard title="Posts" value={fmt(128)} detail="this month" trend="+24" icon={FileText} />
      </div>

      <div className="content-grid">
        <section className="panel chart-panel">
          <div className="panel-header">
            <div>
              <h3>Audience growth</h3>
              <p>Follower and reach movement</p>
            </div>
            <span className="select-pill">Last 30 days</span>
          </div>

          <div className="chart-wrap">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeline}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="metric_date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="followers" strokeWidth={3} dot={false} name="Followers" />
                <Line type="monotone" dataKey="reach" strokeWidth={2} dot={false} name="Reach" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="panel">
          <div className="panel-header">
            <div>
              <h3>Connected channels</h3>
              <p>Your current audience</p>
            </div>
          </div>

          <div className="platform-list">
            {platforms.length ? platforms.map((item) => (
              <div className="platform-row" key={item.platform}>
                <div className="platform-logo">
                  {item.platform === "instagram" ? <Instagram size={20} /> : <Twitter size={20} />}
                </div>
                <div className="platform-info">
                  <strong>{item.username || item.platform}</strong>
                  <small>{item.platform === "instagram" ? "Instagram" : "X / Twitter"}</small>
                </div>
                <strong>{fmt(item.followers_count)}</strong>
              </div>
            )) : (
              <>
                <div className="platform-row">
                  <div className="platform-logo instagram-logo"><Instagram size={20} /></div>
                  <div className="platform-info"><strong>@creator</strong><small>Instagram</small></div>
                  <strong>10,200</strong>
                </div>
                <div className="platform-row">
                  <div className="platform-logo twitter-logo"><Twitter size={20} /></div>
                  <div className="platform-info"><strong>@creator</strong><small>X / Twitter</small></div>
                  <strong>15,230</strong>
                </div>
              </>
            )}
          </div>
        </section>
      </div>
    </>
  );
}
