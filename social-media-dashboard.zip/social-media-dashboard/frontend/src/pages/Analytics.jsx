import { useEffect, useState } from "react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend
} from "recharts";
import api from "../services/api";

const demo = [
  { metric_date: "Sep 01", likes: 420, comments: 80, shares: 35 },
  { metric_date: "Sep 05", likes: 510, comments: 94, shares: 42 },
  { metric_date: "Sep 10", likes: 640, comments: 121, shares: 59 },
  { metric_date: "Sep 15", likes: 710, comments: 135, shares: 64 },
  { metric_date: "Sep 20", likes: 830, comments: 160, shares: 78 },
  { metric_date: "Sep 25", likes: 920, comments: 182, shares: 93 },
  { metric_date: "Sep 30", likes: 1040, comments: 210, shares: 115 }
];

export default function Analytics() {
  const [data, setData] = useState(demo);

  useEffect(() => {
    api.get("/analytics/timeline")
      .then((response) => {
        if (response.data?.length) setData(response.data);
      })
      .catch(() => {});
  }, []);

  return (
    <>
      <section className="page-heading">
        <div>
          <span className="eyebrow">ANALYTICS</span>
          <h2>Understand your audience</h2>
          <p>Track engagement, reach and follower growth over time.</p>
        </div>
      </section>

      <div className="analytics-grid">
        <section className="panel large-chart">
          <div className="panel-header">
            <div>
              <h3>Engagement activity</h3>
              <p>Likes, comments and shares</p>
            </div>
          </div>
          <div className="chart-wrap">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="metric_date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="likes" name="Likes" />
                <Bar dataKey="comments" name="Comments" />
                <Bar dataKey="shares" name="Shares" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="panel large-chart">
          <div className="panel-header">
            <div>
              <h3>Reach trend</h3>
              <p>Audience reach over time</p>
            </div>
          </div>
          <div className="chart-wrap">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="metric_date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="reach" strokeWidth={3} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>
      </div>
    </>
  );
}
