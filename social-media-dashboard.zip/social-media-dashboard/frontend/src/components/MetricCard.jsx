export default function MetricCard({ title, value, detail, icon: Icon, trend }) {
  return (
    <div className="metric-card">
      <div className="metric-top">
        <span>{title}</span>
        <div className="metric-icon">
          <Icon size={19} />
        </div>
      </div>
      <strong className="metric-value">{value}</strong>
      <div className="metric-bottom">
        <span className={trend?.startsWith("-") ? "trend negative" : "trend"}>
          {trend || "—"}
        </span>
        <span>{detail}</span>
      </div>
    </div>
  );
}
