export default function PlatformBadge({ platform }) {
  const name = platform === "twitter" ? "X / Twitter" : "Instagram";
  const cls = platform === "twitter" ? "platform twitter" : "platform instagram";

  return <span className={cls}>{name}</span>;
}
