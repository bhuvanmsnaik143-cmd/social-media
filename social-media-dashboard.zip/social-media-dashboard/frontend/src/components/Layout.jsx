import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  BarChart3,
  CalendarClock,
  FileText,
  LayoutDashboard,
  LogOut,
  UserCircle,
  Menu,
  X
} from "lucide-react";
import { useState } from "react";

export default function Layout({ user, onLogout }) {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const links = [
    { to: "/", label: "Dashboard", icon: LayoutDashboard, end: true },
    { to: "/analytics", label: "Analytics", icon: BarChart3 },
    { to: "/posts", label: "Posts", icon: FileText },
    { to: "/schedule", label: "Schedule", icon: CalendarClock },
    { to: "/profile", label: "Profile", icon: UserCircle }
  ];

  function logout() {
    localStorage.removeItem("social_dashboard_token");
    onLogout();
    navigate("/login");
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${open ? "open" : ""}`}>
        <div className="brand">
          <div className="brand-mark">S</div>
          <div>
            <strong>SocialPulse</strong>
            <small>Analytics Hub</small>
          </div>
        </div>

        <nav>
          {links.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={() => setOpen(false)}
              className={({ isActive }) => isActive ? "nav-item active" : "nav-item"}
            >
              <Icon size={19} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        <button className="logout-button" onClick={logout}>
          <LogOut size={18} />
          Logout
        </button>
      </aside>

      {open && <div className="sidebar-overlay" onClick={() => setOpen(false)} />}

      <main className="main-content">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setOpen(!open)}>
            {open ? <X /> : <Menu />}
          </button>

          <div>
            <span className="eyebrow">SOCIAL MEDIA COMMAND CENTER</span>
            <h1>Welcome, {user?.name?.split(" ")[0] || "Creator"} 👋</h1>
          </div>

          <div className="topbar-user">
            <div className="avatar">
              {user?.name?.charAt(0)?.toUpperCase() || "U"}
            </div>
            <div className="topbar-user-info">
              <strong>{user?.name}</strong>
              <small>{user?.email}</small>
            </div>
          </div>
        </header>

        <div className="page-content">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
